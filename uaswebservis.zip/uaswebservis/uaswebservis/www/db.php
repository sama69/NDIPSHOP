<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id10306332_samafatma82","samafatma82","id10306332_samafatma82") or die ("could not connect database");
?>
